import 'package:flutter/material.dart';

import 'HomeScreen.dart';


void main() {
  runApp(const MaterialApp(home:HomeScreen(), debugShowCheckedModeBanner: false,));
}


