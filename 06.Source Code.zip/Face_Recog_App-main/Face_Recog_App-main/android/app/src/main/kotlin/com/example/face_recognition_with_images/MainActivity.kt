package com.example.face_recognition_with_images

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
